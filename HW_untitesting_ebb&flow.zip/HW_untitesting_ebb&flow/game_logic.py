"""منطق خالص بازی Ebb and Flow — بدون هیچ وابستگی به Pygame."""

import random

# ثابت‌ها
BASE_SCORE       = 50
METER_MAX        = 4
MIN_MULTIPLIER   = 1
MAX_MULTIPLIER   = 10
FINAL_BONUS_BASE = 250
DIRS = [">>>>>", "<<<<<", "^^^^^", "vvvvv"]


class GameState:
    """وضعیت منطقی بازی: امتیاز، ضریب، متر و حالت پاسخ."""

    def __init__(self, rng=None):
        self.rng = rng or random
        self.score = 0
        self.multiplier = MIN_MULTIPLIER
        self.meter = 0
        self.mode = self.rng.choice(["pointing", "moving"])
        self.pointing_dir = self.rng.choice(DIRS)
        self.moving_dir = self.rng.choice(DIRS)

    # ---------- امتیازدهی ----------
    def add_score(self):
        """پاسخ درست: امتیاز + متر. اگر متر پر شد، ضریب بالا می‌رود."""
        self.score += BASE_SCORE * self.multiplier
        self.meter += 1
        upgraded_to = None
        if self.meter >= METER_MAX:
            self.meter = 0
            if self.multiplier < MAX_MULTIPLIER:
                self.multiplier += 1
                upgraded_to = self.multiplier
        return upgraded_to

    def penalize(self):
        """پاسخ غلط: اگر متر پر بود صفر شود، وگرنه ضریب یکی کم شود."""
        if self.meter > 0:
            self.meter = 0
        else:
            self.multiplier = max(self.multiplier - 1, MIN_MULTIPLIER)

    # ---------- بررسی پاسخ ----------
    def is_correct(self, player_dir):
        if self.mode == "pointing":
            return player_dir == self.pointing_dir
        return player_dir == self.moving_dir

    def check(self, player_dir):
        """پاسخ بازیکن را پردازش می‌کند و وضعیت جدید را برمی‌گرداند."""
        correct = self.is_correct(player_dir)
        if correct:
            upgraded_to = self.add_score()
        else:
            self.penalize()
            upgraded_to = None
        self._next_round()
        return correct, upgraded_to

    def _next_round(self):
        self.mode = self.rng.choice(["pointing", "moving"])
        self.pointing_dir = self.rng.choice(DIRS)
        self.moving_dir = self.rng.choice(DIRS)

    # ---------- پایان بازی ----------
    def calculate_final_bonus(self):
        return FINAL_BONUS_BASE * self.multiplier


def compute_bonus_duration_ms(bonus_points, ms_per_point=5,
                              min_ms=1500, max_ms=20000):
    """مدت انیمیشن بونوس را با محدود کردن در بازه [min_ms, max_ms] حساب می‌کند."""
    ms = bonus_points * ms_per_point
    return max(min_ms, min(max_ms, ms))