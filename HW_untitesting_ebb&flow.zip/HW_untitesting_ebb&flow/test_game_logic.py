import unittest
from game_logic import (
    GameState, compute_bonus_duration_ms,
    BASE_SCORE, MIN_MULTIPLIER, MAX_MULTIPLIER,
    METER_MAX, FINAL_BONUS_BASE, DIRS,
)


class FixedRng:
    """یک RNG ساختگی که همیشه خروجی ثابت می‌دهد تا تست‌ها قطعی باشند."""
    def __init__(self, choices):
        self._choices = list(choices)
        self._i = 0

    def choice(self, seq):
        val = self._choices[self._i % len(self._choices)]
        self._i += 1
        return val


class TestAddScore(unittest.TestCase):
    """تست رفتار امتیازدهی و ارتقای ضریب."""

    def setUp(self):
        # rng ساختگی: همیشه "pointing" و ">>>>>" برمی‌گرداند
        self.g = GameState(rng=FixedRng(["pointing", ">>>>>"]))

    def test_first_correct_gives_base_score(self):
        self.g.add_score()
        self.assertEqual(self.g.score, BASE_SCORE * MIN_MULTIPLIER)
        self.assertEqual(self.g.meter, 1)
        self.assertEqual(self.g.multiplier, MIN_MULTIPLIER)

    def test_meter_resets_after_four_correct(self):
        for _ in range(METER_MAX):
            self.g.add_score()
        self.assertEqual(self.g.meter, 0)
        self.assertEqual(self.g.multiplier, MIN_MULTIPLIER + 1)

    def test_score_scales_with_multiplier(self):
        self.g.multiplier = 3
        self.g.add_score()
        self.assertEqual(self.g.score, BASE_SCORE * 3)

    def test_multiplier_does_not_exceed_max(self):
        self.g.multiplier = MAX_MULTIPLIER
        self.g.meter = METER_MAX - 1
        upgraded = self.g.add_score()
        self.assertEqual(self.g.multiplier, MAX_MULTIPLIER)
        self.assertIsNone(upgraded, "در سقف ضریب نباید ارتقا گزارش شود")

    def test_upgrade_returns_new_multiplier(self):
        self.g.meter = METER_MAX - 1
        result = self.g.add_score()
        self.assertEqual(result, MIN_MULTIPLIER + 1)


class TestPenalize(unittest.TestCase):
    """تست جریمه پاسخ غلط."""

    def setUp(self):
        self.g = GameState(rng=FixedRng(["pointing", ">>>>>"]))

    def test_wrong_with_full_meter_resets_meter_only(self):
        self.g.meter = 2
        self.g.multiplier = 5
        self.g.penalize()
        self.assertEqual(self.g.meter, 0)
        self.assertEqual(self.g.multiplier, 5)

    def test_wrong_with_empty_meter_drops_multiplier(self):
        self.g.meter = 0
        self.g.multiplier = 4
        self.g.penalize()
        self.assertEqual(self.g.meter, 0)
        self.assertEqual(self.g.multiplier, 3)

    def test_multiplier_never_below_min(self):
        self.g.meter = 0
        self.g.multiplier = MIN_MULTIPLIER
        self.g.penalize()
        self.assertEqual(self.g.multiplier, MIN_MULTIPLIER)


class TestCheckAnswer(unittest.TestCase):
    """تست تشخیص درست/غلط در دو حالت pointing و moving."""

    def test_correct_pointing(self):
        g = GameState(rng=FixedRng(["pointing", ">>>>>"]))
        g.pointing_dir = ">>>>>"
        correct, _ = g.check(">>>>>")
        self.assertTrue(correct)
        self.assertEqual(g.score, BASE_SCORE)

    def test_wrong_pointing(self):
        g = GameState(rng=FixedRng(["pointing", ">>>>>"]))
        g.pointing_dir = ">>>>>"
        correct, _ = g.check("<<<<<")
        self.assertFalse(correct)
        self.assertEqual(g.score, 0)

    def test_moving_mode_uses_moving_dir_not_visual(self):
        """در حالت moving، جهت visual اصلاً مهم نیست؛ فقط moving_dir."""
        g = GameState(rng=FixedRng(["moving", ">>>>>"]))
        g.moving_dir = "vvvvv"
        g.pointing_dir = "^^^^^"
        correct, _ = g.check("vvvvv")
        self.assertTrue(correct)

    def test_check_advances_round(self):
        # یک لیست طولانی‌تر بدهیم تا برای دور اول و دور دوم کافی باشد
        g = GameState(rng=FixedRng(["pointing", ">>>>>", ">>>>>", "moving", "<<<<<", "vvvvv"]))
        g.check("<<<<<")
        # بعد از هر پاسخ، راند جدید شروع می‌شود
        self.assertIn(g.mode, ("pointing", "moving"))
        self.assertIn(g.pointing_dir, DIRS)
        self.assertIn(g.moving_dir, DIRS)


class TestFinalBonus(unittest.TestCase):
    def test_bonus_is_250_times_multiplier(self):
        g = GameState(rng=FixedRng(["pointing", ">>>>>"]))
        g.multiplier = 4
        self.assertEqual(g.calculate_final_bonus(), FINAL_BONUS_BASE * 4)

    def test_bonus_at_min_multiplier(self):
        g = GameState(rng=FixedRng(["pointing", ">>>>>"]))
        self.assertEqual(g.calculate_final_bonus(), FINAL_BONUS_BASE)


class TestBonusDuration(unittest.TestCase):
    def test_minimum_clamp(self):
        self.assertEqual(compute_bonus_duration_ms(10), 1500)

    def test_maximum_clamp(self):
        self.assertEqual(compute_bonus_duration_ms(100_000), 20000)

    def test_middle_value(self):
        self.assertEqual(compute_bonus_duration_ms(1000), 5000)


if __name__ == "__main__":
    unittest.main(verbosity=2)